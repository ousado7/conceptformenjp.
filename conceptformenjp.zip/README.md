# ConceptForMenJP

Site gerado para publicação no GitHub Pages.

**Usuário GitHub**: `ousado7`

**Como publicar:** faça upload dos arquivos para um repositório chamado `conceptformenjp` e ative *GitHub Pages* nas configurações (branch `main`, root).

**Placeholders para substituir após download:**
- `PREFERENCE_ID_PLACEHOLDER` → cole seu `preference_id` do Mercado Pago (para ativar checkout real).
- `WHATSAPP_NUMBER_ENCODED` → substitua nas páginas `produto-*.html` pelo seu número (ex: `5511912345678`).

**Contato**: emanuelxcosta1@gmail.com
